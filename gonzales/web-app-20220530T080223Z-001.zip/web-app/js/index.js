
		var v = document.getElementById("login");
		var x = document.getElementById("register");
		var z = document.getElementById("btn");

		function register(){
			v.style.left = "-465px"
			x.style.left = "65px"
		
			z.style.left = "17vh"
		}
		function login(){
			v.style.left = "65px"
			x.style.left = "-465px"
			z.style.left = "0px"
		}
		
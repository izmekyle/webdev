<?php
	$conn = new PDO("mysql:host=localhost;dbname=demo", 'root', '');
?>
<?php
	/*
	 * Footer.php
	 * A footer template for all pages
	 *
	 *
	 */

?>

	<div id="footer">This the Footer Section</div>
	</body>
	</html>
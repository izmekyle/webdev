<?php
	/*
	 * side-bar.php
	 *
	 *
	 */
?>

<div id="sidebar">
	
</div>
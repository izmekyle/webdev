<?php
	/*
	 * Header.php
	 * A header template for all pages
	 *
	 *
	 */

?>
	<html>
	<head>
		<link rel="stylesheet" type="text/css" href="./style.css">
	</head>
	<body>
	<div id="header">
	<h1>This the Header Section</h1>
	</div>